package gamefactory;

import gamecollection.*;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

class User{
	private String name;
	protected String[] userScore = new String[4];
	
	public User() {}
	protected User(String name) {
		this.name = name;
	}
	protected String getName() {
		return name;
	}
	protected void setUserScore(int gameNumber, String result) {
		userScore[gameNumber] = result;
	}
}

public class FactoryMain extends User{
	Scanner sc;
	User player;
	private String printStr;
	private boolean answerCheck;
	// 0: 오목 , 1: 숫자야구 , 2: 블랙잭, 3: 지뢰찾기
	private GameMain[] gameKinds = new GameMain[4];
	private String[] surveyAnswer = new String[5];
	
	public FactoryMain() {
		sc = new Scanner(System.in);
	}
	private void slowPrint(String message, long millisPerChar) {
		for (int i = 0; i < message.length(); i++)
        {
            System.out.print(message.charAt(i));
            try
            {
                Thread.sleep(millisPerChar);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
	}
	private boolean userAnswerCheck() {
		while(true) {
			String userAnswer = sc.next();
			if(userAnswer.equals("Y") || userAnswer.equals("y")) {
				return true;
			}
			else if(userAnswer.equals("N") || userAnswer.equals("n")) {
				printStr = "그렇지만 한 번만 해보시는 건 어떨까요?(Y(y) or N(n)) >> ";
				slowPrint(printStr, 40);
				userAnswer = sc.next();
				while(true) {
					if(userAnswer.equals("Y") || userAnswer.equals("y")) {
						return true;
					}
					else if(userAnswer.equals("N") || userAnswer.equals("n")){
						printStr = "네. 알겠습니다.\n\n";
						slowPrint(printStr, 40);
						return false;
					}
					else {
						printStr = "잘못된 입력입니다. 다시 입력해주세요 >> ";
						slowPrint(printStr, 40);
					}
				}
			}
			else {
				printStr = "잘못된 입력입니다. 다시 입력해주세요 >> ";
				slowPrint(printStr, 40);
			}
		}
	}
	private void survey() throws IOException {
		// 설문조사 파일 불러와서 설문조사 하기
		printStr = "설문조사에 참여해주셔서 감사합니다. 아래 간단한 설문에 대하여 주관식으로 답변을 등록해주시면 됩니다.\n\n";
		slowPrint(printStr,40);
		sc.nextLine();
		BufferedWriter bw = new BufferedWriter(new FileWriter("./src/Survey_Result.txt"));
		bw.write("\t\t【 설 문 조 사 】\n");
		bw.newLine();
		bw.write("Q1. 귀하는 저희 숭실 미니 게임 팩토리의 게임을 체험하셨습니까? >> ");
		System.out.println("\t\t【 설 문 조 사 】");
		System.out.print("Q1. 귀하는 저희 숭실 미니 게임 팩토리의 게임을 체험하셨습니까? >> ");
		surveyAnswer[0] = sc.nextLine();
		bw.write(surveyAnswer[0]);
		bw.newLine();
		bw.write("Q2. 귀하는 몇 가지의 미니 게임을 체험하셨습니까? >> ");
		System.out.print("Q2. 귀하는 몇 가지의 미니 게임을 체험하셨습니까? >> ");
		surveyAnswer[1] = sc.nextLine();
		bw.write(surveyAnswer[1]);
		bw.newLine();
		bw.write("Q3. 귀하께서 가장 만족하는 미니 게임은 어떤 것입니까? >> ");
		System.out.print("Q3. 귀하께서 가장 만족하는 미니 게임은 어떤 것입니까? >> ");
		surveyAnswer[2] = sc.nextLine();
		bw.write(surveyAnswer[2]);
		bw.newLine();
		bw.write("Q4. 귀하께서 가장 불만족하는 미니 게임은 어떤 것입니까? >> ");
		System.out.print("Q4. 귀하께서 가장 불만족하는 미니 게임은 어떤 것입니까? >> ");
		surveyAnswer[3] = sc.nextLine();
		bw.write(surveyAnswer[3]);
		bw.newLine();
		bw.write("Q5. 귀하는 다시 방문하실 계획이 있으십니까? >> ");
		System.out.print("Q5. 귀하는 다시 방문하실 계획이 있으십니까? >> ");
		surveyAnswer[4] = sc.nextLine();
		bw.write(surveyAnswer[4]);
		bw.newLine();
		System.out.println();
		printStr = "설문에 참여해주셔서 감사합니다.\n 파일로 저장합니다...\n\n";
		slowPrint(printStr,40);
		bw.close();
		// 설문조사 파일에 저장된 내용 출력
		try {
			BufferedReader br = new BufferedReader(new FileReader("./src/Survey_Result.txt"));
			String line = null;
			while(true) {
				line = br.readLine();
				if(line==null) break;
				System.out.println(line);
			}
			br.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println();
		printStr = "이제 출구 앞 사무실로 가셔서 방문 인증서를 받아가주시기 바랍니다!\n";
		slowPrint(printStr, 40);
	}
	
	private void printFile() throws IOException{
		printStr = "안녕하세요! 사무원 민경남입니다! 저희 숭실 미니 게임 팩토리를 방문해주신 기념으로 방문 인증서를 드리도록 하겠습니다.\n"
					+ "이 방문 인증서는 나중에 숭실 기업에 취직할 때 가산점을 드립니다!\n";
		slowPrint(printStr,40);
		// 전체 스코어를 이용해서 파일 저장 후 보여주기.
		BufferedWriter bw2 = new BufferedWriter(new FileWriter("./src/Visiting_Certificate.txt"));
		bw2.write("-----------------Soongsil Game Factory-----------------\n");
		bw2.write("이름: " + player.getName() + "\n\n");
		bw2.write("<게임의 결과>\n");
		for(int i=0; i<userScore.length; i++) {
			bw2.write(userScore[i]);
			bw2.newLine();
		}
		bw2.newLine();
		bw2.write("위 사람은 숭실 미니 게임 팩토리를 방문하여 게임을 체험하였습니다.\n" + "게임에 대한 이해가 높으며, 성실히 체험하였으므로 이 인증서를 수여합니다.\n");
		bw2.write("\t\t【(주)숭실 기업®】사장 민경남 ㎖ \n");
		bw2.write("--------------------------------------------------------");
		bw2.close();
		
		printStr = "여기 방문 인증서 출력이 완료되었습니다! 메일로도 보내드렸습니다!\n";
		slowPrint(printStr,40);
		System.out.println();
		try{BufferedReader br2 = new BufferedReader(new FileReader("./src/Visiting_Certificate.txt"));
			while(true) {
				String line = br2.readLine();
				if(line==null) break;
				System.out.println(line);
			}
			br2.close();
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() throws IOException {
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("<<< O____O >>>");
		printStr = "안녕하세요.숭실 미니 게임 팩토리에 오신 것을 환영합니다!\n" + "당신의 하루를 책임 질 AI가이드 민숭실입니다. 당신의 성함은 어떻게 되시나요?(성함 입력 후 Enter) >> ";
		slowPrint(printStr, 40);
		
		String name = sc.nextLine();
		player = new User(name);
		
		printStr = player.getName() + "님, 만나서 반갑습니다!\n" + "공장을 둘러보면서 공장에 대하여 소개를 하도록 하겠습니다.\n"
					+ "자 먼저 공장 입구에 있는 이 지도를 함께 보시면, 이 '★'가 표시된 곳이 현재 위치입니다.\n" + "저와 함께 공장을 구경하면서 게임 체험관에서 게임도 체험해 볼 예정입니다.\n";
		slowPrint(printStr, 40);
		try{
            Thread.sleep(100);
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
		System.out.println();
		System.out.println("                       < Soongsil Game Factory >               ");
		System.out.println("| ===오 목==================================== 숫자 야구 ==========================");
		System.out.println("|     ★ ");
		System.out.println("| ====================== 블랙  잭 ====================================지뢰 찾기=====");
		System.out.println();
	
		printStr = "현재 위치에서 쭉 직진하면 출구이며, 출구가 나오기 전에 있는 게임 체험관들을 체험해보도록 하겠습니다.\n" 
				+ "먼저 왼쪽을 보시면 '오목' 게임의 체험관이 보이나요? 오목은 바둑판에 두 사람이 번갈아 돌을 놓아 가로나 세로, 대각선으로 다섯 개의 연속된 돌을 놓으면 이기는 게임입니다.\n"
				+ "보통 19*19 또는 15*15 크기의 바둑판에서 게임을 하지만 저희는 10*10의 미니 오목을 만들었습니다.\n" 
				+ "또한 사람 대 사람이 아니라, 사람 대 AI민숭실의 대결입니다.\n" + "체험해보시겠습니까?(Y(y) or N(n)) >> ";
		slowPrint(printStr,40);
		answerCheck = userAnswerCheck();
		if(answerCheck) {
			gameKinds[0] = (Omok) new Omok(player.getName());
			gameKinds[0].startScreen();
			gameKinds[0].run();
			setUserScore(0, gameKinds[0].allScore[0]);
			System.out.println("<<< O____O >>>");
			printStr = "오목 게임은 잘 즐기셨나요?\n" + "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~\n";
			slowPrint(printStr,40);
		}
		else {
			setUserScore(0,"오목 게임을 체험 하지 않았습니다.");
			System.out.println("<<< O____O >>>");
			printStr = "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~\n";
			slowPrint(printStr,40);
		}
		
		//지도 보여주기, 블랙잭 설명하기
		System.out.println();
		System.out.println("                       < Soongsil Game Factory >               ");
		System.out.println("| ===오 목==================================== 숫자 야구 ==========================");
		System.out.println("|                          ★ ");
		System.out.println("| ====================== 블랙  잭 ====================================지뢰 찾기=====");
		System.out.println();
		
		printStr = "자 오른쪽에 보이는 여기는 블랙 잭 게임 체험관입니다! 혹시 블랙 잭에 대해 아시나요?\n" 
				+ "블랙잭은 쉽게 설명해서 딜러와 손님이 카드 2장을 받아 21에 가까운 수를 만드는 사람이 이기게 됩니다.\n"
				+ "이론상의 승률은 49.72%. 고로 50%에 가까운 승률을 가지고 있으니 카지노게임 중 최고라고 할수 있죠.\n"
				+ "체험해보시겠습니까?(Y(y) or N(n)) >> ";
		slowPrint(printStr,40);
		answerCheck = userAnswerCheck();
		if(answerCheck) {
			gameKinds[1] = (BlackJack) new BlackJack(player.getName());
			gameKinds[1].startScreen();
			gameKinds[1].run();
			setUserScore(1, gameKinds[1].allScore[1]);
			System.out.println("<<< O____O >>>");
			printStr = "블랙 잭 게임은 잘 즐기셨나요? 어때요 쉽지 않죠? 하하 ^^\n" + "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~";
			slowPrint(printStr,40);
		}
		else {
			setUserScore(1,"블랙 잭 게임을 체험하지 않았습니다.");
			System.out.println("<<< O____O >>>");
			printStr = "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~\n";
			slowPrint(printStr,40);
		}
		
		
		System.out.println();
		System.out.println("                       < Soongsil Game Factory >               ");
		System.out.println("| ===오 목==================================== 숫자 야구 ==========================");
		System.out.println("|                                              ★ ");
		System.out.println("| ====================== 블랙  잭 ====================================지뢰 찾기=====");
		System.out.println();
		
		printStr = "왼쪽에 보이는 이 곳은 숫자 야구 게임 체험관입니다! 혹시 숫자 야구 게임에 대해 아시나요?\n" 
				+ "숫자 야구는 학창 시절 학생들이 종이와 펜만 있으면 할 수 있던 재밌는 게임이죠!!\n"
				+ "체험해보시겠습니까?(Y(y) or N(n)) >> ";
		slowPrint(printStr,40);
		answerCheck = userAnswerCheck();
		if(answerCheck) {
			gameKinds[2] = (NumberBaseball) new NumberBaseball(player.getName());
			gameKinds[2].startScreen();
			gameKinds[2].run();
			setUserScore(2, gameKinds[2].allScore[2]);
			System.out.println("<<< O____O >>>");
			printStr = "숫자 야구 게임은 잘 즐기셨나요?\n" + "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~";
			slowPrint(printStr,40);
		}
		else {
			setUserScore(2,"숫자 야구 게임을 체험하지 않았습니다.");
			System.out.println("<<< O____O >>>");
			printStr = "이제 다음 게임 체험관으로 이동하겠습니다. 저를 따라오세요~\n";
			slowPrint(printStr,40);
		}
		
		System.out.println();
		System.out.println("                       < Soongsil Game Factory >               ");
		System.out.println("| ===오 목==================================== 숫자 야구 ==========================");
		System.out.println("|                                                                    ★ ");
		System.out.println("| ====================== 블랙  잭 ====================================지뢰 찾기=====");
		System.out.println();
		
		printStr = "자 여기는 지뢰 찾기 게임 체험관입니다! 지뢰 찾기 게임에 대해 아시나요?\n" 
				+ "지뢰 찾기 게임은 아주 오래 전부터 컴퓨터에서 즐길 수 있었던 간단한 게임입니다.\n"
				+ "체험해보시겠습니까?(Y(y) or N(n)) >> ";
		slowPrint(printStr,40);
		answerCheck = userAnswerCheck();
		if(answerCheck) {
			gameKinds[3] = (Mine) new Mine(player.getName());
			gameKinds[3].startScreen();
			gameKinds[3].run();
			setUserScore(3, gameKinds[3].allScore[3]);
			System.out.println("<<< O____O >>>");
			printStr = "지뢰 찾기 게임은 재밌게 즐기셨나요?\n" + "오랜만에 어릴 적 게임하던 추억을 떠올리셨나요~?\n" 
						+ "아쉽게도 다른 게임들은 비공개로 개발 중이므로 체험할 수 있는 게임은 여기까지입니다.\n";
			slowPrint(printStr,40);
		}
		else {
			setUserScore(3,"지뢰 찾기 게임을 체험하지 않았습니다.");
			System.out.println();
			System.out.println("<<< O____O >>>");
			printStr = "오늘 하루 어떠셨나요? 오랜만에 어릴 적 게임하던 추억을 떠올리셨나요~?\n" 
					+ "아쉽게도 다른 게임들은 비공개로 개발 중이므로 체험할 수 있는 게임은 여기까지입니다.\n";
			slowPrint(printStr,40);
		}
		
		// 설문조사 
		printStr = "마지막으로, 체험한 게임들의 만족도에 관한 설문조사를 해주시겠습니까?(Y(y) or N(n)) >> ";
		slowPrint(printStr,40);
		String answer = sc.next();
		//
		if(answer.equals("Y") || answer.equals("y")) {
			survey();
		}
		else if(answer.equals("N") || answer.equals("n")) {
			printStr = "네 알겠습니다! 출구 앞 사무실로 가셔서 방문 인증서를 받아가주세요!\n\n";
			slowPrint(printStr,40);
		}
		else {
			while(true) {
				printStr = "잘못된 입력입니다. Y(y) 또는 N(n)만 입력해주세요!\n";
				slowPrint(printStr,40);
				answer = sc.next();
				if(answer.equals("Y") || answer.equals("y")) {
					survey();
					break;
				}
				else if(answer.equals("N") || answer.equals("n")) {
					printStr = "네 알겠습니다! 출구 앞 사무실로 가셔서 방문 인증서를 받아가주세요!\n\n";
					slowPrint(printStr,40);
					break;
				}
			}
		}
		//방문 인증서 > 숭실체험관 취업할 때 가산점 드림.
		printFile();
		// 종료
		System.out.println();
		System.out.println("<<< O____O >>>");
		printStr = "저희 숭실 게임 팩토리를 방문하신 시간이 즐거우셨다면 좋겠습니다.\n"
					+ "앞으로도 저희 숭실 게임 팩토리는 더 좋은 게임을 개발하도록 노력하겠습니다.\n"
					+ "안녕히 가세요~!\n";
		slowPrint(printStr,40);
		
		sc.close();
	}
	
	public static void main(String[] args) throws IOException {
		FactoryMain f = new FactoryMain();
		f.run();
	}
	
}
